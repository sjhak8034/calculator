package Week4Hw;

public class DivideOperation extends AbstractOperation {
    @Override
    public double operate(int a, int b) {
        return (double) a / b;
    }
}
