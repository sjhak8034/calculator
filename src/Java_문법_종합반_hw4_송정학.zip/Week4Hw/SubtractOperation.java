package Week4Hw;

public class SubtractOperation extends AbstractOperation {
    @Override
    public double operate(int a, int b) {

        return a - b;

    }
}

