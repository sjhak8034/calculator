package Week4Hw;

public abstract class AbstractOperation extends Calculator {

    abstract double operate(int a, int b);
}
