package CalculatorForWeek3Hw;

public class AddOperation extends AbstractOperation {
    @Override
    public double operate(int a, int b) {
        return a + b;
    }
}
