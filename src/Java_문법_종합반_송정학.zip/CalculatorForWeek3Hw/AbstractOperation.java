package CalculatorForWeek3Hw;

public abstract class AbstractOperation extends Calculator {

    abstract double operate(int a, int b);
}
